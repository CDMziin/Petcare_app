import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/pet_provider.dart';
import '../widgets/reminders_widget.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pets = Provider.of<PetProvider>(context).pets;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Bem-vindo de volta!', style: Theme.of(context).textTheme.titleLarge),
          if (pets.isNotEmpty) Text('Cuide bem dos seus pets!'),
          const SizedBox(height: 16),
          Text('Lembretes', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          RemindersWidget(),
        ],
      ),
    );
  }
}
