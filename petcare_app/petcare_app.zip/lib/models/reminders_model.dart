class ReminderModel {
  final String petId;
  final String title;
  final DateTime date;

  ReminderModel({
    required this.petId,
    required this.title,
    required this.date,
  });

  factory ReminderModel.fromJson(Map<String, dynamic> json) => ReminderModel(
        petId: json['petId'] ?? '',
        title: json['title'] ?? '',
        date: DateTime.parse(json['date']),
      );

  Map<String, dynamic> toJson() => {
        'petId': petId,
        'title': title,
        'date': date.toIso8601String(),
      };

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ReminderModel &&
          runtimeType == other.runtimeType &&
          petId == other.petId &&
          title == other.title &&
          date == other.date;

  @override
  int get hashCode => petId.hashCode ^ title.hashCode ^ date.hashCode;
}
