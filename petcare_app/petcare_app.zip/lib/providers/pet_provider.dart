import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/pet_model.dart';

class PetProvider extends ChangeNotifier {
  List<PetModel> _pets = [];

  List<PetModel> get pets => _pets;

  PetProvider() {
    loadPets();
  }

  Future<void> loadPets() async {
    final prefs = await SharedPreferences.getInstance();
    final petStrList = prefs.getStringList('pets') ?? [];
    _pets = petStrList.map((p) => PetModel.fromJson(json.decode(p))).toList();
    notifyListeners();
  }

  Future<void> addPet(PetModel pet) async {
    _pets.add(pet);
    await _save();
    notifyListeners();
  }

  Future<void> removePet(String id) async {
    _pets.removeWhere((p) => p.id == id);
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    final petStrList = _pets.map((p) => json.encode(p.toJson())).toList();
    await prefs.setStringList('pets', petStrList);
  }
}


