import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:provider/provider.dart';
import '../models/reminders_model.dart';
import '../providers/pet_provider.dart';

class RemindersWidget extends StatefulWidget {
  const RemindersWidget({super.key});

  @override
  State<RemindersWidget> createState() => _RemindersWidgetState();
}

class _RemindersWidgetState extends State<RemindersWidget> {
  List<ReminderModel> reminders = [];
  final TextEditingController _controller = TextEditingController();
  String? _selectedPetId;
  DateTime? _selectedDate;
  String? _filterPetId;

  @override
  void initState() {
    super.initState();
    _loadReminders();
  }

  Future<void> _loadReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final reminderStr = prefs.getStringList('lembretes') ?? [];
    setState(() {
      reminders = reminderStr.map((r) => ReminderModel.fromJson(json.decode(r))).toList();
    });
  }

  Future<void> _saveReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final reminderStr = reminders.map((r) => json.encode(r.toJson())).toList();
    await prefs.setStringList('lembretes', reminderStr);
  }

  void _addReminder() {
    final text = _controller.text.trim();
    if (text.isNotEmpty && _selectedPetId != null) {
      final newReminder = ReminderModel(
        petId: _selectedPetId!,
        title: text,
        date: _selectedDate ?? DateTime.now(),
      );
      setState(() {
        reminders.add(newReminder);
        _controller.clear();
        _selectedDate = null;
      });
      _saveReminders();
    }
  }

  void _removeReminder(ReminderModel r) {
    setState(() {
      reminders.remove(r);
    });
    _saveReminders();
  }

  void _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pets = Provider.of<PetProvider>(context).pets;
    final filtered = _filterPetId == null
        ? reminders
        : reminders.where((r) => r.petId == _filterPetId).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                decoration: const InputDecoration(hintText: 'Novo lembrete'),
              ),
            ),
            IconButton(icon: const Icon(Icons.date_range), onPressed: _pickDate),
            DropdownButton<String>(
              value: _selectedPetId,
              hint: const Text('Pet'),
              onChanged: (val) => setState(() => _selectedPetId = val),
              items: pets.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
            ),
            IconButton(icon: const Icon(Icons.add), onPressed: _addReminder),
          ],
        ),
        DropdownButton<String?>(
          hint: const Text('Filtrar por Pet'),
          value: _filterPetId,
          onChanged: (val) => setState(() => _filterPetId = val),
          items: [
            const DropdownMenuItem(value: null, child: Text('Todos')),
            ...pets.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))),
          ],
        ),
        const SizedBox(height: 10),
        if (filtered.isEmpty)
          const Center(child: Text('Nenhum lembrete ainda.')),
        ...filtered.map((r) => Card(
              child: ListTile(
                title: Text(r.title),
                subtitle: Text(
                    'Para: ${pets.firstWhere((p) => p.id == r.petId).name}\nData: ${r.date.toLocal().toString().split(' ')[0]}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _removeReminder(r),
                ),
              ),
            )),
      ],
    );
  }
}
